create FUNCTION prime_number ( num1 NUMBER )
   RETURN NUMBER  -- 반환 데이터타입은 NUMBER
IS
  has_div NUMBER := 1;
BEGIN
	 
	FOR div IN 2..sqrt(num1)
	LOOP
		IF MOD(num1, div) = 0 THEN
			has_div := 0;
			EXIT;
		END IF;
		
	END LOOP;
		
	IF has_div = 1 THEN
			  DBMS_OUTPUT.PUT_LINE (num1 || '는 소수');
	END IF;
      
	RETURN has_div;
END;
/

